// DemiPay v5.4 QA Verification Build
console.log("🚀 DemiPay v5.4 QA Verification Build Loaded");
console.log("📅 Release Date: 29 Oct 2025");
console.log("✅ Verified by: QA Team");
console.log("🎨 Themes: Light + Dark Mode");

// Initialize application state
const appState = {
    theme: 'light',
    transactionCount: 0,
    logs: []
};

// Theme toggle functionality
const themeToggle = document.getElementById('themeToggle');
const logEntries = document.getElementById('logEntries');

function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    appState.theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
    
    // Update button text
    themeToggle.textContent = appState.theme === 'dark' ? '☀️ Toggle Light Mode' : '🌙 Toggle Dark Mode';
    
    // Log the event
    logEvent(`Theme switched to ${appState.theme.toUpperCase()} mode`);
    console.log(`🎨 Theme changed to: ${appState.theme}`);
}

// Event logging function
function logEvent(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    
    appState.logs.push(logEntry);
    console.log(`📝 ${logEntry}`);
    
    // Update UI log
    const logElement = document.createElement('div');
    logElement.className = 'log-entry';
    logElement.textContent = logEntry;
    logEntries.insertBefore(logElement, logEntries.firstChild);
    
    // Keep only last 10 entries in UI
    if (logEntries.children.length > 10) {
        logEntries.removeChild(logEntries.lastChild);
    }
}

// Transaction module functions
function sendPayment() {
    appState.transactionCount++;
    logEvent(`💸 Send Payment initiated - Transaction #${appState.transactionCount}`);
    console.log(`💸 Transaction #${appState.transactionCount}: Send Payment`);
    
    // Simulate transaction processing
    setTimeout(() => {
        logEvent(`✅ Payment sent successfully - Transaction #${appState.transactionCount}`);
        console.log(`✅ Transaction #${appState.transactionCount} completed`);
    }, 1000);
}

function receivePayment() {
    appState.transactionCount++;
    logEvent(`📥 Receive Payment initiated - Transaction #${appState.transactionCount}`);
    console.log(`📥 Transaction #${appState.transactionCount}: Receive Payment`);
    
    // Simulate transaction processing
    setTimeout(() => {
        logEvent(`✅ Payment received successfully - Transaction #${appState.transactionCount}`);
        console.log(`✅ Transaction #${appState.transactionCount} completed`);
    }, 1000);
}

function viewHistory() {
    logEvent(`📊 Transaction history viewed - Total transactions: ${appState.transactionCount}`);
    console.log(`📊 Transaction History:`);
    console.log(`   Total Transactions: ${appState.transactionCount}`);
    console.log(`   Current Theme: ${appState.theme}`);
    console.log(`   Log Entries: ${appState.logs.length}`);
}

// Event listeners
themeToggle.addEventListener('click', toggleTheme);
document.getElementById('sendBtn').addEventListener('click', sendPayment);
document.getElementById('receiveBtn').addEventListener('click', receivePayment);
document.getElementById('historyBtn').addEventListener('click', viewHistory);

// Initialize with welcome message
window.addEventListener('DOMContentLoaded', () => {
    console.log("🎯 DemiPay Application Initialized");
    logEvent("🎯 DemiPay v5.4 QA Verification Build initialized");
    logEvent("✅ All systems operational");
    logEvent("🔄 Ready for v5.5 upgrade testing");
});

// QA Test Functions
const QATests = {
    testThemeToggle: function() {
        console.log("🧪 Running Theme Toggle Test...");
        const initialTheme = appState.theme;
        toggleTheme();
        const newTheme = appState.theme;
        const passed = initialTheme !== newTheme;
        console.log(`${passed ? '✅' : '❌'} Theme Toggle Test: ${passed ? 'PASSED' : 'FAILED'}`);
        return passed;
    },
    
    testTransactionModule: function() {
        console.log("🧪 Running Transaction Module Test...");
        const initialCount = appState.transactionCount;
        sendPayment();
        receivePayment();
        setTimeout(() => {
            const passed = appState.transactionCount === initialCount + 2;
            console.log(`${passed ? '✅' : '❌'} Transaction Module Test: ${passed ? 'PASSED' : 'FAILED'}`);
        }, 1500);
    },
    
    testEventLogging: function() {
        console.log("🧪 Running Event Logging Test...");
        const initialLogCount = appState.logs.length;
        logEvent("Test log entry");
        const passed = appState.logs.length === initialLogCount + 1;
        console.log(`${passed ? '✅' : '❌'} Event Logging Test: ${passed ? 'PASSED' : 'FAILED'}`);
        return passed;
    },
    
    runAllTests: function() {
        console.log("🧪 ========================================");
        console.log("🧪 Starting DemiPay v5.4 QA Test Suite");
        console.log("🧪 ========================================");
        
        const results = {
            themeToggle: this.testThemeToggle(),
            eventLogging: this.testEventLogging()
        };
        
        this.testTransactionModule();
        
        setTimeout(() => {
            console.log("🧪 ========================================");
            console.log("🧪 QA Test Suite Complete");
            console.log("🧪 ========================================");
            logEvent("🧪 QA Test Suite executed - Check console for results");
        }, 2000);
        
        return results;
    }
};

// Expose QA tests to global scope for manual testing
window.QATests = QATests;

console.log("💡 Tip: Run 'QATests.runAllTests()' in console to execute full test suite");