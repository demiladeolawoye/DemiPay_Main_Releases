const state = {
  user: null,
  balance: 250000,
  kycLevel: "Tier 2 (BVN Verified)",
  tx: []
};

function formatNaira(amount) {
  return "₦" + amount.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function showToast(type, message, isSystem = false) {
  const el = document.getElementById(isSystem ? "systemToast" : "globalToast");
  if (!el) return;
  el.textContent = message;
  el.className = "";
  el.classList.add(type === "error" ? "toast-error" : type === "success" ? "toast-success" : "toast-info");
  el.style.display = "block";
  setTimeout(() => { el.style.display = "none"; }, 2600);
}

function initUser() {
  const fromStorage = localStorage.getItem("pay54_user");
  if (fromStorage) {
    state.user = JSON.parse(fromStorage);
  } else {
    state.user = { name: "Demi", paytag: "@demi", country: "NG", email: "demo@pay54.app" };
  }
  document.getElementById("userDisplayName").textContent = state.user.name;
  document.getElementById("welcomeName").textContent = state.user.name;
  document.getElementById("walletAddress").textContent = "Account: P54-1029345678";
  document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
  document.getElementById("kycLevel").textContent = state.kycLevel;
}

function initTheme() {
  const saved = localStorage.getItem("pay54_theme");
  if (saved === "light") {
    document.body.classList.add("light-mode");
    document.body.classList.remove("dark-mode");
    document.getElementById("themeIcon").textContent = "🌞";
    document.getElementById("themeText").textContent = "Dark mode";
  } else {
    document.body.classList.add("dark-mode");
    document.body.classList.remove("light-mode");
    document.getElementById("themeIcon").textContent = "🌙";
    document.getElementById("themeText").textContent = "Light mode";
  }
}

function toggleTheme() {
  const body = document.body;
  const isDark = body.classList.contains("dark-mode");
  if (isDark) {
    body.classList.remove("dark-mode");
    body.classList.add("light-mode");
    localStorage.setItem("pay54_theme", "light");
    document.getElementById("themeIcon").textContent = "🌞";
    document.getElementById("themeText").textContent = "Dark mode";
    showToast("info", "☀️ Light mode enabled");
  } else {
    body.classList.remove("light-mode");
    body.classList.add("dark-mode");
    localStorage.setItem("pay54_theme", "dark");
    document.getElementById("themeIcon").textContent = "🌙";
    document.getElementById("themeText").textContent = "Light mode";
    showToast("success", "🌙 Dark mode enabled");
  }
}

function initUserMenu() {
  const btn = document.getElementById("userMenuBtn");
  const dropdown = document.getElementById("userMenuDropdown");
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    dropdown.classList.toggle("show");
  });
  document.addEventListener("click", () => dropdown.classList.remove("show"));

  document.getElementById("menuProfile").addEventListener("click", () =>
    showToast("info", "Profile centre coming in full app.")
  );
  document.getElementById("menuSettings").addEventListener("click", () =>
    showToast("info", "Settings will manage PIN, biometrics & limits.")
  );
  document.getElementById("menuSupport").addEventListener("click", () =>
    showToast("info", "Support: help@pay54.app (demo).")
  );
  document.getElementById("menuLogout").addEventListener("click", () => {
    localStorage.removeItem("pay54_user");
    window.location.href = "login.html";
  });
}

function initScrollTop() {
  const btn = document.getElementById("scrollTopBtn");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 220) btn.classList.add("show");
    else btn.classList.remove("show");
  });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function seedTransactions() {
  state.tx = [
    { type: "sent", title: "Sent to @prem", meta: "P2P • PAY54", amount: -15000, status: "completed" },
    { type: "received", title: "From Upwork Payout", meta: "FX • USD→₦", amount: 120000, status: "completed" },
    { type: "sent", title: "Electricity (Ikeja Disco)", meta: "Bills • Meter 0012345678", amount: -18000, status: "completed" },
    { type: "sent", title: "Bolt Ride", meta: "Shop on the Fly • Taxi", amount: -3500, status: "completed" },
    { type: "received", title: "Salary from DemiTech Ltd", meta: "Bank Transfer • Zenith", amount: 300000, status: "completed" }
  ];
  renderTransactions();
}

function renderTransactions() {
  const list = document.getElementById("transactionsList");
  if (!state.tx.length) {
    list.innerHTML = "<p style='font-size:0.8rem;color:#9ca3af;'>No recent transactions yet.</p>";
    return;
  }
  list.innerHTML = state.tx.map(t => {
    const iconClass = t.type === "sent" ? "sent" : "recv";
    const iconEmoji = t.type === "sent" ? "⬆️" : "⬇️";
    const amountClass = t.amount < 0 ? "tx-amount-neg" : "tx-amount-pos";
    return `
      <div class="tx-item">
        <div class="tx-left">
          <div class="tx-icon ${iconClass}">${iconEmoji}</div>
          <div class="tx-text">
            <div class="tx-title">${t.title}</div>
            <div class="tx-meta">${t.meta}</div>
          </div>
        </div>
        <div class="tx-right">
          <div class="${amountClass}">${formatNaira(Math.abs(t.amount))}</div>
          <div class="tx-status">${t.status}</div>
        </div>
      </div>
    `;
  }).join("");
}

// Money moves (simple mock flows)
function handleSendMoney() {
  const to = prompt("Send to PAYtag, email or bank (demo):", "@prem");
  if (!to) return;
  const amtStr = prompt("Amount in ₦:", "5000");
  const amt = Number(amtStr || "0");
  if (!amt || amt <= 0) {
    showToast("error", "Enter a valid amount.");
    return;
  }
  if (amt > state.balance) {
    showToast("error", "Insufficient balance (demo).");
    return;
  }
  state.balance -= amt;
  document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
  state.tx.unshift({
    type: "sent",
    title: `Sent to ${to}`,
    meta: "P2P • PAY54 (mock)",
    amount: -amt,
    status: "completed"
  });
  renderTransactions();
  showToast("success", `Sent ${formatNaira(amt)} to ${to} (mock).`);
}

function handleReceiveMoney() {
  const from = prompt("Who is sending you money?", "Client / Friend");
  if (!from) return;
  const amtStr = prompt("Expected amount (₦):", "10000");
  const amt = Number(amtStr || "0");
  if (!amt || amt <= 0) {
    showToast("error", "Enter a valid amount.");
    return;
  }
  state.balance += amt;
  document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
  state.tx.unshift({
    type: "received",
    title: `From ${from}`,
    meta: "Incoming payment (mock)",
    amount: amt,
    status: "completed"
  });
  renderTransactions();
  showToast("success", `Marked ${formatNaira(amt)} as received from ${from} (mock).`);
}

function handleAddWithdraw() {
  const mode = prompt("Type 'add' to fund or 'withdraw' to cash out:", "add");
  if (!mode) return;
  const amtStr = prompt("Amount (₦):", "5000");
  const amt = Number(amtStr || "0");
  if (!amt || amt <= 0) {
    showToast("error", "Enter a valid amount.");
    return;
  }
  if (mode.toLowerCase() === "withdraw") {
    if (amt > state.balance) {
      showToast("error", "Insufficient balance to withdraw (demo).");
      return;
    }
    state.balance -= amt;
    state.tx.unshift({
      type: "sent",
      title: "Cashout to Bank/Agent",
      meta: "Add / Withdraw (mock)",
      amount: -amt,
      status: "completed"
    });
  } else {
    state.balance += amt;
    state.tx.unshift({
      type: "received",
      title: "Funded from Card/Bank",
      meta: "Add / Withdraw (mock)",
      amount: amt,
      status: "completed"
    });
  }
  document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
  renderTransactions();
  showToast("success", `Recorded ${mode.toLowerCase()} of ${formatNaira(amt)} (mock).`);
}

function handleBankTransfer() {
  const bank = prompt("Bank Name (demo)", "GTBank");
  const acct = prompt("Account Number (10‑digit)", "0123456789");
  const amtStr = prompt("Amount (₦)", "20000");
  const amt = Number(amtStr || "0");
  if (!bank || !acct || !amt || amt <= 0) {
    showToast("error", "Please fill all fields (mock).");
    return;
  }
  if (amt > state.balance) {
    showToast("error", "Insufficient balance (demo).");
    return;
  }
  state.balance -= amt;
  state.tx.unshift({
    type: "sent",
    title: `Bank transfer to ${bank}`,
    meta: `Acct: ${acct}`,
    amount: -amt,
    status: "completed"
  });
  document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
  renderTransactions();
  showToast("success", `Bank transfer of ${formatNaira(amt)} to ${bank} (mock).`);
}

// Services (simplified)
function handleCrossBorder() {
  alert("🌍 Cross‑Border FX demo: NG ➝ GH, KE, ZA, UK, US (full converter UI in later build).");
}

function handleSavings() {
  alert("💰 Savings & Goals demo: create pots, standing orders & progress (wired in next sprint).");
}

function handleBills() {
  alert("💡 Bills demo: Electricity, Water, TV & Airtime forms (UI from previous spec).");
}

function handleCards() {
  alert("💳 Cards demo: P54 virtual + linked cards with default selection (full UI in dedicated screen).");
}

function handleShop() {
  const url = "https://www.jumia.com.ng/";
  window.open(url, "_blank", "noopener");
  showToast("info", "🏬 Opened Shop on the Fly partner (demo link).");
}

function handleInvest() {
  alert("📈 Investments demo: Buy sample stocks/ETFs with USD or NGN (portfolio view later).");
}

function handleAgent() {
  alert("🧍‍♂️ Agent demo: Business name, NIN & selfie capture (mobile camera via file input).");
}

function handleAiRisk() {
  alert("🤖 AI Risk Watch demo: flags risky behaviour, runs server‑side in real PAY54.");
}

function initActions() {
  document.getElementById("sendMoneyBtn").addEventListener("click", handleSendMoney);
  document.getElementById("receiveMoneyBtn").addEventListener("click", handleReceiveMoney);
  document.getElementById("addWithdrawBtn").addEventListener("click", handleAddWithdraw);
  document.getElementById("bankTransferBtn").addEventListener("click", handleBankTransfer);

  document.getElementById("serviceCrossBorder").addEventListener("click", handleCrossBorder);
  document.getElementById("serviceSavings").addEventListener("click", handleSavings);
  document.getElementById("serviceBills").addEventListener("click", handleBills);
  document.getElementById("serviceCards").addEventListener("click", handleCards);
  document.getElementById("serviceShop").addEventListener("click", handleShop);
  document.getElementById("serviceInvest").addEventListener("click", handleInvest);
  document.getElementById("serviceAgent").addEventListener("click", handleAgent);
  document.getElementById("serviceAiRisk").addEventListener("click", handleAiRisk);

  document.getElementById("refreshBalanceBtn").addEventListener("click", () => {
    const delta = Math.floor(Math.random() * 20000) - 10000;
    state.balance = Math.max(0, state.balance + delta);
    document.getElementById("balanceAmount").textContent = formatNaira(state.balance);
    showToast("info", "Balance refreshed (mock sync).");
  });

  document.getElementById("viewAllTxBtn").addEventListener("click", () =>
    showToast("info", "In full app this opens full statements.")
  );
}

document.addEventListener("DOMContentLoaded", () => {
  initUser();
  initTheme();
  initUserMenu();
  initScrollTop();
  seedTransactions();

  document.getElementById("themeToggle").addEventListener("click", toggleTheme);
  document.getElementById("brandHome").addEventListener("click", () =>
    window.scrollTo({ top: 0, behavior: "smooth" })
  );

  initActions();
});
