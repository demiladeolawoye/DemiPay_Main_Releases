console.log("DemiPay v5.4 QA Verification Build Loaded");

// Theme toggle logic
const toggleTheme = () => {
    document.body.classList.toggle("dark-mode");
};

document.body.addEventListener("click", toggleTheme);
