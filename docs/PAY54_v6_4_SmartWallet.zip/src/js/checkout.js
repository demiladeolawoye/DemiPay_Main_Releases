function getQueryParams() {
  const params = {};
  const qs = window.location.search.substring(1);
  if (!qs) return params;
  qs.split("&").forEach((pair) => {
    const [k, v] = pair.split("=");
    params[decodeURIComponent(k)] = decodeURIComponent(v || "");
  });
  return params;
}

function showToast(message) {
  const el = document.getElementById("globalToast");
  el.textContent = message;
  el.className = "toast-info";
  el.style.display = "block";
  setTimeout(() => (el.style.display = "none"), 2600);
}

document.addEventListener("DOMContentLoaded", () => {
  const params = getQueryParams();
  const details = document.getElementById("checkoutDetails");

  const amount = params.amount || "0.00";
  const currency = params.currency || "NGN";
  const merchant = params.merchant || "Demo Store";
  const ref = params.ref || "PAY54‑DEMO‑" + Date.now();

  details.innerHTML = `
    <div><strong>Merchant:</strong> ${merchant}</div>
    <div><strong>Amount:</strong> ${currency} ${amount}</div>
    <div><strong>Reference:</strong> ${ref}</div>
    <div><strong>Status:</strong> Paid (mock)</div>
  `;

  document.getElementById("viewReceiptBtn").addEventListener("click", () => {
    showToast("Opening receipt (mock PDF)…");
  });

  document.getElementById("backToStoreBtn").addEventListener("click", () => {
    if (params.return_url) {
      window.location.href = params.return_url;
    } else {
      window.location.href = "index.html";
    }
  });
});
